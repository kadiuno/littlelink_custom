# A LittleLink Custom Theme
Find more themes: https://github.com/JulianPrieber/llc-themes
                                                                                                                                                                         
*	Theme Name: Stargazer
*	Theme Version: 1.2
*	Theme Date: 2022-09-01
*	Theme Author: JulianPrieber
*	Theme Author URI: https://github.com/JulianPrieber
*	Theme License: GPLv3
*	Source code: https://github.com/JulianPrieber/stargazer

## Preview:
![Preview](https://i.imgur.com/S84rKl4.gif)


### Used assets:
* Built using:
* https://github.com/dhg/Skeleton
* License: MIT

* Built using:
* https://codepen.io/SuneBear/pen/YzVgebG
* License: MIT

* Built using:
* https://codepen.io/trishalim/pen/WNEOdWK
* License: MIT
