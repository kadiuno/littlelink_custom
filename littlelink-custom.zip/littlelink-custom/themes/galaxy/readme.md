# A LittleLink Custom Theme
Find more themes: https://github.com/JulianPrieber/llc-themes
                                                                                                                                                                         
*	Theme Name: Galaxy
*	Theme Version: 1.6
*	Theme Date: 2022-06-09
*	Theme Author: JulianPrieber
*	Theme Author URI: https://github.com/JulianPrieber
*	Theme License: GPLv3
*	Source code: https://github.com/JulianPrieber2/galaxy


### Used assets:
* Built using:
* https://github.com/dhg/Skeleton
* License: MIT

*
* https://github.com/johnggli/linktree
* License: MIT -> https://github.com/johnggli/linktree/blob/master/LICENSE.md
