  _    _                 _                   _                   _      _ _   _   _      _      _       _       _____          _                  
 | |  | |               | |                 | |                 | |    (_) | | | | |    | |    (_)     | |     / ____|        | |                 
 | |__| | _____      __ | |_ ___    ___  ___| |_   _   _ _ __   | |     _| |_| |_| | ___| |     _ _ __ | | __ | |    _   _ ___| |_ ___  _ __ ___  
 |  __  |/ _ \ \ /\ / / | __/ _ \  / __|/ _ \ __| | | | | '_ \  | |    | | __| __| |/ _ \ |    | | '_ \| |/ / | |   | | | / __| __/ _ \| '_ ` _ \ 
 | |  | | (_) \ V  V /  | || (_) | \__ \  __/ |_  | |_| | |_) | | |____| | |_| |_| |  __/ |____| | | | |   <  | |___| |_| \__ \ || (_) | | | | | |
 |_|  |_|\___/ \_/\_/    \__\___/  |___/\___|\__|  \__,_| .__/  |______|_|\__|\__|_|\___|______|_|_| |_|_|\_\  \_____\__,_|___/\__\___/|_| |_| |_|
                                                        | |                                                                                       
                                                        |_|                                                                                       

To set up LittleLink Custom, download the latest release from GitHub and simply put the folder 'littlelink-custom' in the root directory of your website.

That's it! No coding no command line setup just plug and play.

Now access your install of LittleLink Custom with 'your-domain-name.com/littlelink-custom'.

At first, you will be greeted with a 'MissingAppKeyException'.
This is totally normal on first setups, simply click on the 'Generate app key' button and then 'Refresh now' and you're done.

You can now log in to the Admin Panel with the credentials:
  email: admin@admin.com
  password: 12345678


Optional configuration:
Optionally, you can change the app name in your ".env" file in the root directory of your LittleLink Custom installation. At the moment this is set to
APP_NAME="LittleLink Custom" you can change "LittleLink Custom" to what ever you like. This setting defines the page title and welcome message.

Additionally, the littlelink-custom directory can be renamed to anything you see fit, further customizing your personal LittleLink Custom install.