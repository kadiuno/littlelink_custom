# A LittleLink Custom Theme
Find more themes: https://github.com/JulianPrieber/llc-themes
                                                                                                                                                                         
*	Theme Name: Mono
*	Theme Version: 1.3
*	Theme Date: 2022-05-18
*	Theme Author: JulianPrieber
*	Theme Author URI: https://github.com/JulianPrieber
*	Theme License: GPLv3
*	Source code: https://github.com/JulianPrieber/mono


### Used assets:
* Built using:
* https://github.com/dhg/Skeleton
* License: MIT

* https://github.com/JulianPrieber/littlelink-mono
* License: MIT
